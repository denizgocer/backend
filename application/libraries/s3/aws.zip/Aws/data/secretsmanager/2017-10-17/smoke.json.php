<?php
// This file was auto-generated from sdk-root/src/data/secretsmanager/2017-10-17/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListSecrets', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeSecret', 'input' => [ 'SecretId' => 'fake-secret-id', ], 'errorExpectedFromService' => true, ], ],];
